import logging

import azure.functions as func
import requests
from requests.structures import CaseInsensitiveDict
import json

def main(myblob: func.InputStream):
    name = myblob.name
    logging.info(f"Python blob trigger function processed blob \n"
                 f"Name: {myblob.name}\n"
                 f"Blob Size: {myblob.length} bytes")
    url = "url"

    headers = CaseInsensitiveDict()
    headers["Authorization"] = "PAT"
    headers["Content-Type"] = "application/json"
    dict1 = {
        "Param" : name
    }
    dict2 = {
        "parameters": json.dumps(dict1),
        "definition": {
            "id": id
        }   
    }
    # resp = requests.post(url, headers=headers, data=data)
    resp = requests.post(url, headers=headers, data=json.dumps(dict2))
    logging.info(f"code works")

    # print(resp.status_code)
